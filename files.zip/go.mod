module expensebot

go 1.22
