// Package parser превращает текст вида "450 продукты вчера" в структуру траты.
package parser

import (
	"errors"
	"regexp"
	"strconv"
	"strings"
	"time"
	"unicode"
)

var (
	ErrNoAmount  = errors.New("не нашёл сумму")
	ErrBadAmount = errors.New("сумма должна быть больше нуля")
)

// Entry — результат разбора одной строки.
type Entry struct {
	Amount   int64 // в копейках
	Category string
	Comment  string
	SpentAt  time.Time
}

// Одно сообщение может содержать несколько трат: их разделяют перенос строки,
// точка с запятой или запятая с пробелом (запятая без пробела — это "85,5").
var splitRe = regexp.MustCompile(`[\n;]+|,\s+`)

// Split разбивает сообщение на отдельные строки-траты.
func Split(text string) []string {
	var out []string
	for _, p := range splitRe.Split(text, -1) {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

// ParseLine разбирает одну трату. now — время сообщения в часовом поясе пользователя.
//
// Понимает: "450 продукты", "такси 1200", "85,5 кофе", "300р кино",
// "1.5к аренда", "500 подарок вчера", "500 подарок 25.09", "500 подарок 25.09.2026".
func ParseLine(line string, now time.Time) (Entry, error) {
	tokens := strings.Fields(line)

	var cands []int
	for i, t := range tokens {
		if _, ok := parseAmount(t); ok {
			cands = append(cands, i)
		}
	}
	if len(cands) == 0 {
		return Entry{}, ErrNoAmount
	}

	// Если чисел несколько, "25.09" похоже на дату — сумма это другое число.
	amountIdx := cands[0]
	if len(cands) > 1 {
		amountIdx = cands[len(cands)-1]
		for _, i := range cands {
			if _, ok := parseShortDate(tokens[i], now); !ok {
				amountIdx = i
				break
			}
		}
	}

	amount, _ := parseAmount(tokens[amountIdx])
	if amount <= 0 {
		return Entry{}, ErrBadAmount
	}

	spent := now
	dateFound := false
	var words []string
	for i, t := range tokens {
		if i == amountIdx {
			continue
		}
		if !dateFound {
			if d, ok := parseDate(t, now); ok {
				spent, dateFound = d, true
				continue
			}
		}
		words = append(words, t)
	}

	category, comment := resolveCategory(strings.Join(words, " "))
	return Entry{Amount: amount, Category: category, Comment: comment, SpentAt: spent}, nil
}

// ---- сумма ----

// 450 | 85,5 | 12.50 | 300р | 1.5к | 100₽ | 20zł
var amountRe = regexp.MustCompile(`^(\d{1,9})(?:[.,](\d{1,2}))?([кk])?(?:р|р\.|руб|руб\.|₽|zł|pln|usd|eur|\$|€)?$`)

// parseAmount возвращает сумму в копейках.
func parseAmount(tok string) (int64, bool) {
	m := amountRe.FindStringSubmatch(strings.ToLower(tok))
	if m == nil {
		return 0, false
	}
	whole, _ := strconv.ParseInt(m[1], 10, 64)
	var frac int64
	if m[2] != "" {
		f := m[2]
		if len(f) == 1 {
			f += "0" // "85,5" = 85 руб 50 коп
		}
		frac, _ = strconv.ParseInt(f, 10, 64)
	}
	total := whole*100 + frac
	if m[3] != "" {
		total *= 1000 // "1.5к" = 1500
	}
	return total, true
}

// ---- дата ----

var (
	shortDateRe = regexp.MustCompile(`^(\d{1,2})\.(\d{1,2})$`)
	fullDateRe  = regexp.MustCompile(`^(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})$`)
	relDays     = map[string]int{"сегодня": 0, "вчера": -1, "позавчера": -2}
)

func parseDate(tok string, now time.Time) (time.Time, bool) {
	low := strings.ToLower(tok)
	if d, ok := relDays[low]; ok {
		return now.AddDate(0, 0, d), true
	}
	if m := fullDateRe.FindStringSubmatch(low); m != nil {
		y, _ := strconv.Atoi(m[3])
		if len(m[3]) == 2 {
			y += 2000
		}
		return makeDate(y, m[1], m[2], now)
	}
	return parseShortDate(low, now)
}

// parseShortDate разбирает "25.09". Если такая дата в этом году ещё не наступила
// (больше чем завтра), считаем, что имелся в виду прошлый год.
func parseShortDate(tok string, now time.Time) (time.Time, bool) {
	m := shortDateRe.FindStringSubmatch(tok)
	if m == nil {
		return time.Time{}, false
	}
	t, ok := makeDate(now.Year(), m[1], m[2], now)
	if ok && t.After(now.AddDate(0, 0, 1)) {
		t, ok = makeDate(now.Year()-1, m[1], m[2], now)
	}
	return t, ok
}

func makeDate(year int, dd, mm string, now time.Time) (time.Time, bool) {
	d, _ := strconv.Atoi(dd)
	mo, _ := strconv.Atoi(mm)
	if mo < 1 || mo > 12 || d < 1 || d > 31 {
		return time.Time{}, false
	}
	t := time.Date(year, time.Month(mo), d, 12, 0, 0, 0, now.Location())
	if t.Day() != d || int(t.Month()) != mo { // например, 31.02
		return time.Time{}, false
	}
	if t.Year() == now.Year() && t.YearDay() == now.YearDay() {
		return now, true
	}
	return t, true
}

// ---- категория ----

type rule struct {
	category string
	stems    []string // начала слов, в нижнем регистре, ё заменена на е
}

var rules = []rule{
	{"Продукты", []string{"продукт", "еда", "магазин", "супермаркет", "пятероч", "магнит", "перекрест", "ашан", "овощ", "фрукт", "хлеб", "молок", "мясо", "рынок"}},
	{"Кафе и рестораны", []string{"кафе", "кофе", "ресторан", "обед", "ужин", "завтрак", "пицц", "суши", "бургер", "макдон", "столов", "доставк"}},
	{"Транспорт", []string{"такси", "убер", "uber", "bolt", "метро", "автобус", "трамвай", "маршрутк", "проезд", "бензин", "заправк", "парковк", "электричк", "поезд", "транспорт"}},
	{"Жильё", []string{"аренд", "квартир", "коммунал", "жкх", "ипотек"}},
	{"Связь и интернет", []string{"телефон", "связь", "интернет", "мобильн", "симк", "тариф"}},
	{"Здоровье", []string{"аптек", "врач", "лекарств", "таблетк", "больниц", "клиник", "стоматолог", "анализ", "здоровь"}},
	{"Развлечения", []string{"кино", "театр", "концерт", "игра", "игры", "steam", "стим", "бильярд", "боулинг", "клуб", "развлеч"}},
	{"Одежда", []string{"одежд", "куртк", "футболк", "джинс", "обув", "кроссовк", "ботинк"}},
	{"Подписки", []string{"подписк", "netflix", "spotify", "youtube", "ютуб", "кинопоиск"}},
	{"Подарки", []string{"подар"}},
	{"Образование", []string{"курс", "книг", "учеб", "обучен"}},
	{"Дом и быт", []string{"быт", "хозтовар", "ikea", "икеа", "уборк", "мебел", "посуд"}},
}

func norm(s string) string {
	return strings.ReplaceAll(strings.ToLower(s), "ё", "е")
}

// resolveCategory ищет категорию по словарю. Если слов нет в словаре:
// 1-2 слова становятся новой категорией ("Ремонт машины"), длинный текст —
// комментарием к категории "Другое".
func resolveCategory(text string) (category, comment string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return "Другое", ""
	}
	for _, w := range strings.Fields(norm(text)) {
		w = strings.Trim(w, ".,!?:()\"'")
		for _, r := range rules {
			for _, s := range r.stems {
				if strings.HasPrefix(w, s) {
					if norm(text) == norm(r.category) {
						return r.category, ""
					}
					return r.category, truncate(text, 200)
				}
			}
		}
	}
	if len(strings.Fields(text)) <= 2 {
		return truncate(capitalize(text), 40), ""
	}
	return "Другое", truncate(text, 200)
}

func capitalize(s string) string {
	r := []rune(s)
	r[0] = unicode.ToUpper(r[0])
	return string(r)
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n])
}
